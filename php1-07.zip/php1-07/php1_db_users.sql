INSERT INTO `php1-db`.users (id, login, password, name) VALUES (1, 'Pupkin', 'qwerty', 'Увасилий');
INSERT INTO `php1-db`.users (id, login, password, name) VALUES (2, 'admin', 'admin', 'Админстантин');
INSERT INTO `php1-db`.users (id, login, password, name) VALUES (3, 'user', '42', 'Юзерслав');