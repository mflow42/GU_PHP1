<a href="/">Назад</a>
<div class="photo" style="display: flex; justify-content: center" >
    <img src="/img/error.png">
</div>