<br>
<?=$message?>
<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 20.07.2018
 * Time: 19:43
 */
?>
<form action="" method="post">
    <div>Логин: <input type="text" name="login"></div>
    <div>Пароль: <input type="password" name="password"></div>
    <div><input type="submit" value="Войти"></div>
</form>
