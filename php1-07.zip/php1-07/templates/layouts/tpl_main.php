<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gallery</title>
    <link rel="stylesheet" href="css/main.css">
</head>

<body>
Это хедер с меню
<br>
<a href="/catalogue.php">В каталог</a>
<br>
<a href="/cart.php">Корзина</a>
<?=$content?>
Это футер
</body>
</html>