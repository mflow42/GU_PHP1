<?php
?>
<form class="gallery-upload" action="/photo.php?id=<?=$img['id']?>" method="get">
    <input name="id" type="text"/>
    <input type="submit" value="Показать картинку"/>
</form>
