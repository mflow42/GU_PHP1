<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 21.07.2018
 * Time: 1:35
 */
?>
<h1>Привет, <?=$user['name']?></h1>

<a href="/index.php">На главную</a>

<br>