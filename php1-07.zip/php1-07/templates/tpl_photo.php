<a href="/index.php">Назад</a>
<div class="photo">
    <img src="<?=$path?>" alt="<?=$name?>" class="photo__img">
    <div class="photo__description">Количество просмотров: <?=$visitedCount?></div>
</div>