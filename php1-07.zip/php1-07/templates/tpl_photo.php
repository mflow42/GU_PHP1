<a href="/">Назад</a>
<div class="photo">
    <img src="<?=$oneImageUrl?>" alt="<?=$oneImageName?>" class="photo__img">
    <div class="photo__description">Количество просмотров: <?=$oneImageVisitedNumber?></div>
</div>