<?php
define("ROOT_DIR", $_SERVER["DOCUMENT_ROOT"] . "/");
define("CONFIG_DIR", ROOT_DIR . "../config/");
define("ENGINE_DIR", ROOT_DIR . "../engine/");
define("VENDOR_DIR", ROOT_DIR . "../vendor/");
define("TEMPLATES_DIR", ROOT_DIR . "../templates/");
define("UPLOADS_DIR", ROOT_DIR . "img/");
define("UPLOADS_NORM_DIR", UPLOADS_DIR . "normal/");
define("UPLOADS_MIN_DIR", UPLOADS_DIR . "thumbnails/");
define("PRODUCTS_DIR", UPLOADS_DIR . "products/");
?>