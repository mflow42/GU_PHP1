<?php

$config = [
    'server' => 'localhost',
    'login' => 'root',
    'password' => '',
    'dbName' => 'php1-db',
];
?>